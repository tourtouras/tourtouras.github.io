// Created by iWeb 3.0.4 local-build-20120726

setTransparentGifURL('Media/transparent.gif');function applyEffects()
{var registry=IWCreateEffectRegistry();registry.registerEffects({stroke_0:new IWStrokeParts([{rect:new IWRect(-1,1,2,491),url:'investments_a_old_files/stroke.png'},{rect:new IWRect(-1,-1,2,2),url:'investments_a_old_files/stroke_1.png'},{rect:new IWRect(1,-1,398,2),url:'investments_a_old_files/stroke_2.png'},{rect:new IWRect(399,-1,2,2),url:'investments_a_old_files/stroke_3.png'},{rect:new IWRect(399,1,2,491),url:'investments_a_old_files/stroke_4.png'},{rect:new IWRect(399,492,2,2),url:'investments_a_old_files/stroke_5.png'},{rect:new IWRect(1,492,398,2),url:'investments_a_old_files/stroke_6.png'},{rect:new IWRect(-1,492,2,2),url:'investments_a_old_files/stroke_7.png'}],new IWSize(400,493))});registry.applyEffects();}
function hostedOnDM()
{return false;}
function onPageLoad()
{loadMozillaCSS('investments_a_old_files/investments_a_oldMoz.css')
adjustLineHeightIfTooBig('id1');adjustFontSizeIfTooBig('id1');adjustLineHeightIfTooBig('id3');adjustFontSizeIfTooBig('id3');adjustLineHeightIfTooBig('id4');adjustFontSizeIfTooBig('id4');adjustLineHeightIfTooBig('id5');adjustFontSizeIfTooBig('id5');adjustLineHeightIfTooBig('id6');adjustFontSizeIfTooBig('id6');adjustLineHeightIfTooBig('id7');adjustFontSizeIfTooBig('id7');adjustLineHeightIfTooBig('id8');adjustFontSizeIfTooBig('id8');adjustLineHeightIfTooBig('id9');adjustFontSizeIfTooBig('id9');adjustLineHeightIfTooBig('id10');adjustFontSizeIfTooBig('id10');adjustLineHeightIfTooBig('id11');adjustFontSizeIfTooBig('id11');detectBrowser();fixupIECSS3Opacity('id2');fixAllIEPNGs('Media/transparent.gif');Widget.onload();applyEffects()}
function onPageUnload()
{Widget.onunload();}

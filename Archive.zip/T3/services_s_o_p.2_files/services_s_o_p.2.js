// Created by iWeb 3.0.4 local-build-20120726

setTransparentGifURL('Media/transparent.gif');function applyEffects()
{var registry=IWCreateEffectRegistry();registry.registerEffects({shadow_1:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#000000',opacity:0.500000}),stroke_0:new IWStrokeParts([{rect:new IWRect(-1,1,2,89),url:'services_s_o_p.2_files/stroke.png'},{rect:new IWRect(-1,-1,2,2),url:'services_s_o_p.2_files/stroke_1.png'},{rect:new IWRect(1,-1,502,2),url:'services_s_o_p.2_files/stroke_2.png'},{rect:new IWRect(503,-1,2,2),url:'services_s_o_p.2_files/stroke_3.png'},{rect:new IWRect(503,1,2,89),url:'services_s_o_p.2_files/stroke_4.png'},{rect:new IWRect(503,90,2,2),url:'services_s_o_p.2_files/stroke_5.png'},{rect:new IWRect(1,90,502,2),url:'services_s_o_p.2_files/stroke_6.png'},{rect:new IWRect(-1,90,2,2),url:'services_s_o_p.2_files/stroke_7.png'}],new IWSize(504,91)),shadow_0:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#000000',opacity:0.500000})});registry.applyEffects();}
function hostedOnDM()
{return false;}
function onPageLoad()
{loadMozillaCSS('services_s_o_p.2_files/services_s_o_p.2Moz.css')
adjustLineHeightIfTooBig('id1');adjustFontSizeIfTooBig('id1');adjustLineHeightIfTooBig('id3');adjustFontSizeIfTooBig('id3');adjustLineHeightIfTooBig('id4');adjustFontSizeIfTooBig('id4');adjustLineHeightIfTooBig('id5');adjustFontSizeIfTooBig('id5');detectBrowser();adjustLineHeightIfTooBig('id6');adjustFontSizeIfTooBig('id6');adjustLineHeightIfTooBig('id7');adjustFontSizeIfTooBig('id7');fixupIECSS3Opacity('id2');fixAllIEPNGs('Media/transparent.gif');Widget.onload();applyEffects()}
function onPageUnload()
{Widget.onunload();}
